function capitalizeString(str) {
  var words = str.split(" ");
  for (var i = 0; i < words.length; i++) {
    words[i] = words[i][0].toUpperCase() + words[i].substring(1);
  }
  return words.join(" ");
}

var inputString = prompt("Введіть рядок:");
var capitalizedString = capitalizeString(inputString);
console.log("Вихідний рядок:", capitalizedString);
