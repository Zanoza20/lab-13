var cities = ["Ternopil", "Lviv", "Warsaw"];
var result = cities.join("*");
console.log(result);