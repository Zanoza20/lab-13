var numbers = [2, 3, 4, 5];
var product = 1;

for (var i = 0; i < numbers.length; i++) {
  product *= numbers[i];
}

console.log("Добуток елементів масиву (for):", product);