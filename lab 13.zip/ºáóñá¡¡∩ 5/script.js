function randArray(k) {
  var array = [];
  for (var i = 0; i < k; i++) {
    var randomNum = Math.floor(Math.random() * 500) + 1;
    array.push(randomNum);
  }
  return array;
}

var result = randArray(5);
console.log(result);
