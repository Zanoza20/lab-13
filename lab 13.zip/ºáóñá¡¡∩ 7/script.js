function findMin() {
    var min = arguments[0];
    for (var i = 1; i < arguments.length; i++) {
      if (arguments[i] < min) {
        min = arguments[i];
      }
    }
    return min;
  }
  
  var result = findMin(12, 14, 4, -4, 0.2);
  console.log("Мінімальне значення:", result);
  